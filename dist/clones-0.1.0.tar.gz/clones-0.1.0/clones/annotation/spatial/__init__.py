from .graphs import WeightedGraph
